
// ATHEEM TECH MD Bot Entry Point
require('./src/main'); // Entry to bot main file
